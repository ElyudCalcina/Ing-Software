"""Código fuente del laboratorio."""
